from tests import run_tests
 
# Node class --> Blueprint used to create Linked List!
class Node:
    def __init__(self, value, nextNode=None):
        self.value = value
        self.nextNode = nextNode

    # Returns the linked list, you don't have to worry about this
    def __repr__(self):
        if self.nextNode:
            rest_repr = ", " + repr(self.nextNode)
        else:
            rest_repr = ""
        return "Node(" +repr(self.value) + rest_repr + ")"
    # Prints the linked list, you don't have to worry about this
    def __str__(self):
        string = "<"
        while self.nextNode is not None:
            string += str(self.value) + ""
            self = self.nextNode
        return string + str(self.value) + ">"
 
def createLinkedLst(x):
    """ Create and return a linked list that counts from 0 to x (inclusive).
 
    >>> LLst = createLinkedLst(4)
    >>> Node.__repr__(LLst)
    'Node(0, Node(1, Node(2, Node(3, Node(4)))))'
   
    """
    

 
def addToBegin(linkedList, x):
    """ Add a new node to the begining of the given linked list and return
    that new linked list.
 
    >>> LLst = Node(1, Node(2, Node(3)))
    >>> newLLst = addToBegin(LLst, 0)
    >>> Node.__str__(newLLst)
    '<0123>'
   
    """
    

 
def deleteEnd(linkedList):
    """ Delete a node at the end of a given list, and return the new linked list.
    
    >>> LLst = Node('red', Node('blue', Node('green', Node('yellow'))))
    >>> newLLst = deleteEnd(LLst)
    >>> Node.__str__(newLLst)
    '<redbluegreen>'

    """
    

 
def reverseLst(linkedList):
    """ Reverse the given linked list. For example if the list goes:
    1 -> 2 -> 3 -> 4, Node(1, Node(2, Node(3, Node(4)))), <1234>, this function
    should return 4 -> 3 -> 2 -> 1, Node(4, Node(3, Node(2, Node(1)))), <4321>
 
    >>> linked = Node(1, Node(2, Node(3, Node(4))))
    >>> newLinked = reverseLst(linked)
    >>> Node.__str__(newLinked)
    '<4321>'

    >>> LLst = Node('a', Node('b', Node('c', Node('d'))))
    >>> newLLst = reverseLst(LLst)
    >>> Node.__repr__(newLLst)
    "Node('d', Node('c', Node('b', Node('a'))))"
   
    """
    

   
 
if __name__ == "__main__":
    run_tests()

# Create by Vincent Lee 2022
