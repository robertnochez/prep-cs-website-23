

"""YOUR TESTS WILL RUN AUTOMATICALLY"""


def run_tests():
    from doctest import testmod
    testmod(verbose=True)