from tests import run_tests

def num_eights(x):
    """Returns the number of times 8 appears as a digit of x.

    >>> num_eights(3)
    0
    >>> num_eights(8)
    1
    >>> num_eights(88888888)
    8
    >>> num_eights(2638)
    1
    >>> num_eights(86380)
    2
    >>> num_eights(12345)
    0
    >>> from construct_check import check
    >>> # ban all assignment statements
    >>> check(HW_SOURCE_FILE, 'num_eights',
    ...       ['Assign', 'AugAssign'])
    True
    """
    "*** YOUR CODE HERE ***"


def pingpong(n):
    """Return the nth element of the ping-pong sequence.

    >>> pingpong(8)
    8
    >>> pingpong(10)
    6
    >>> pingpong(15)
    1
    >>> pingpong(21)
    -1
    >>> pingpong(22)
    -2
    >>> pingpong(30)
    -2
    >>> pingpong(68)
    0
    >>> pingpong(69)
    -1
    >>> pingpong(80)
    0
    >>> pingpong(81)
    1
    >>> pingpong(82)
    0
    >>> pingpong(100)
    -6
    >>> from construct_check import check
    >>> # ban assignment statements
    >>> check(HW_SOURCE_FILE, 'pingpong', ['Assign', 'AugAssign'])
    True
    """
    "*** YOUR CODE HERE ***"


def compress(lst):
    """Given a deep list of integers, return a new list compressing all neighboring integers.
    
    >>> compress([])
    []
    >>> compress([1, 2, 3])
    [6]
    >>> compress([0, 0, 0, 0])
    [0]
    >>> compress([1, 2, [3, 4]])
    [3, [7]]
    >>> compress([[11, 12], 3, 4, [1, 2], [5, 6], 7, 8, [9, 10]])
    [[23], 7, [3], [11], 15, [19]]
    """
    "*** YOUR CODE HERE ***"


def make_func_repeater(f, x):
    """
    >>> incr_1 = make_func_repeater(lambda x: x + 1, 1)
    >>> incr_1(2)
    3
    >>> incr_1(5)
    6
    """
    "*** YOUR CODE HERE ***"



    

if __name__ == "__main__":
    run_tests()