from operator import *
from tests import run_tests


def iter_calc(fn):
    """Write a reusable HOF that first takes in a built in method, FN, that uses
    two arguments, and then a numerical index. Perform calls to FN with 
    successive digts from 1 up to the specified index. USE HOF's.

    >>> iter_calc(add)(5) 
    15
    >>> iter_calc(pow)(4)
    1
    >>> iter_calc(mul)(5)
    120
    """
    pass


def find_item(lst, item):
    """Write a function that first takes in a list of tuples, and a specified key. 
    Without assigning any variables or using any loops, iterate through all the tuples 
    and return a list with those that contain the specified value.

    >>> find_item([(True, 17), ("Hello", 21, False), (17 , "GO BEARS")], 17)
    [(True, 17), (17, 'GO BEARS')]

    >>> find_item([(21, 3, 18), (True, False), (True, True, 18), (13, False)], True)
    [(True, False), (True, True, 18)]
    """
    pass


if __name__ == "__main__":
    run_tests()
