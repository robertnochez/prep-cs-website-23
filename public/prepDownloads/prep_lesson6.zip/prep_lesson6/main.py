from tests import run_tests
from operator import *

first_list = [
    ("Fairy", "Godmother"),
    ("Prince", "Charming"),
    ("Princess", "Fiona"),
]

second_list = [
    ("Tomas", "The Train", 45),
    ("Winnie", "The Pooh", 24),
    ("Oski", "Bear", 36),
    ("Mickey", "Mouse", 75)
]

###############################
######### LESSON CODE #########
###############################


def first_names(lst):
    """Takes in a list of people, with each person listed as a tuple, and returns
    a list of the first names of everyone in the list. The overall format of lst is:
    [(first1, last1, age1), (first2, last2, age2) ...]

    >>> first_names(first_list)
    ['Fairy', 'Prince', 'Princess']
    >>> first_names(second_list)
    ['Tomas', 'Winnie', 'Oski', 'Mickey']
    """
    i, num_ppl, firsts = 0, len(lst), []  # 'i' is commonly used as counter
    while i < num_ppl:
        name = lst[i][0]  # access the first element of the i-th item in lst
        firsts.append(name)
        i += 1
    return firsts


def tup_to_dict(lst):
    """Takes in a list of 2-item tuples and returns a dictionary with the items
    as key-value pairs in the format {firstItem: secondItem, ...}

    >>> tup_to_dict(first_list) 
    {"Fairy": "Godmother", "Prince": "Charming", "Princess": "Fiona"}
    """
    i, num_pairs, d = 0, len(lst), {}
    while i < num_pairs:
        pair = lst[i]
        first, second = pair[0], pair[1]
        d[first] = second
        i += 1
    return d


#####################################
######### PRACTICE PROBLEMS #########
#####################################


def first_names_for(lst):
    """Takes in a list of people, with each person listed as a tuple, and returns
    a list of the first names of everyone in the list. The overall format of lst is:
    [(first1, last1, age1), (first2, last2, age2) ...]

    >>> first_names(first_list)
    ['Fairy', 'Prince', 'Princess']
    >>> first_names(second_list)
    ['Tomas', 'Winnie', 'Oski', 'Mickey']
    """
    pass


def tup_to_dict_for(lst):
    """Takes in a list of 2-item tuples and returns a dictionary with the items
    as key-value pairs in the format {firstItem: secondItem, ...}

    >>> tup_to_dict(first_list) 
    {"Fairy": "Godmother", "Prince": "Charming", "Princess": "Fiona"}
    """
    pass


def last_names(lst):
    """Takes in a list of people, with each person listed as a tuple, and returns
    a list of the first names of everyone in the list. The overall format of lst is:
    [(first1, last1, age1), (first2, last2, age2) ...]

    >>> last_names(first_list)
    ['Godmother', 'Charming', 'Fiona']
    >>> last_names(second_list)
    ['The Train', 'The Pooh', 'Bear', 'Mouse']
    """
    pass


def zip_lists(lst1, lst2):
    """Takes 2 lists and puts them together as key value pairs of a dictionary.
    Dictionary structure should be: {i-th elem of lst1: i-th elem of lst2 ...}

    >>> zip_lists([1, 2, 3], ["one", "two", "three"])
    {1: 'one', 2: 'two', 3: 'three'}
    """
    pass


def unzip_dict(d):
    """Takes a dictionary and returns its key-value pairs stored as 2-item tuples
    within a list. Format of tuples should be (<key>, <value>)

    >>> unzip_dict({1: 'one', 2: 'two', 3: 'three'})
    [(1, 'one'), (2, 'two'), (3, 'three)]
    """
    pass


if __name__ == "__main__":
    run_tests()
