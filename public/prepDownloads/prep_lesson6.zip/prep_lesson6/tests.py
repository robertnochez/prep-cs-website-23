

"""Tests will run automatically!"""


def run_tests():
    from doctest import testmod
    testmod(verbose=True)
