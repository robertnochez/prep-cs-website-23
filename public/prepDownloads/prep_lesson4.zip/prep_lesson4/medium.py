var = 3
def foo(bar):
    var = 2
    if bar:
        print("bar is valid")
        return bar
    else:
        print("bar is invalid")
        return bar
   
def hello(world):
    global var
    var = 7
    if (world):
        return var
    elif world == 8:
        return "world is 8"
    else:
        var = 7
        return world
 
def go(bears):
    if bears:
        return "bears is valid"
    elif bears == var:
        return "bears is var"
    else:
        return bears
 
x = foo(3)
foo(None)
hello(8)
y = go([])
go(19)
 
# Created by Laila Walker 2022
