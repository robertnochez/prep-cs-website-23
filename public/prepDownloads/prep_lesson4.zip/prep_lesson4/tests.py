

"""YOUR TESTS WILL AUTOMATICALLY RUN"""




def run_tests():
    from doctest import testmod
    testmod(verbose=True)