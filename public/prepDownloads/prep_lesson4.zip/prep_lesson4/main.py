from tests import run_tests

def quadType(a, b, c, d):
    """ Identify the type of the given quadrilateral. If at there are 2 groups of parallel
    sides, print "I am a rectangle!", if all the sides are the same print "I am a square!".
    If any of the sides are equal to zero print: "Am I really a quadrilateral?", else print: 
    "I don't know what I am!" 

    >>> quadType(6, 9, 6, 9)
    "I am a rectangle!"
    >>> quadType(1, 7, 1, 7)
    "I am a rectangle!"
    >>> quadType(4, 4, 4, 4)
    "I am a square"
    >>> quadType(4, 3, 2, 0)
    "I don't know what I am!"
    >>> quadType(4, 3, 2, 1)
    "Am I really a quadrilateral?"
    """
    pass

def oddOrEven(x):
    """Begin at a given integer number. If it is even, divide by two and subtract 1. 
    If the number is odd, multiply it by 3 and add 4. 

    >>> oddOrEven(4)
    1
    >>> oddOrEven(3)
    13
    """
    pass





if __name__ == "__main__":
    run_tests()