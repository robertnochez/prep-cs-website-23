from operator import add, sub, mul, mod     

x, y = "", 4

def hello(world):
    global add          # reference to global variable instead of local
    if world:
        add = sub
        return we(add)
    else:
        add = mul
        return they(add)

def we(outside):
    global mul, mod
    if not outside == add:
        mul = outside
        return mul
    elif outside == mod:
        mod = mul
        return mod
    else:
        print("We happy outside.")
        mod = outside
        return mod

def they(are_bears):
    global sub 
    if not not not are_bears == mod:
        print("GO BEARS OR GO HOME!")
        sub = are_bears
    elif not not are_bears == add:
        print("THIS IS BEAR TERRITORY!")
        sub = are_bears
    else:
        print("This is the last statement")
    return sub
