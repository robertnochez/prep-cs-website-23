from tests import run_tests

def divisors(x):
    """Iterate from zero to a given value (inclusive), printing whether 
    the current index is divisible by 2, 3, or 5. If a number is only 
    divisible by one of these, only print that. If it is divisible by 
    all three options, print all three. 

    >>> divisors(6)
    0 is divisible by 2, is divisible by 3, is divisible by 5,
    1
    2 is divisible by 2,
    3 is divisible by 3,
    4 is divisible by 2,
    5 is divisible by 5,
    6 is divisible by 2, is divisible by 3,
    """
    pass

def hailstone(x):
    """Begin at a given integer number. If it is even, divide by two. 
    If the number is odd, multiply it by 3 and add 1. Continue this 
    process until the number 1 is reached. Print the integer at each step. 

    >>> hailstone(4)
    4
    2
    1
    >>> hailstone(3)
    3
    10
    5
    16
    8
    4
    2
    1
    """
    pass





if __name__ == "__main__":
    run_tests()