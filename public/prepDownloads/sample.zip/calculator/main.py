from tests import run_tests


def add(x, y):
    """add is a function that takes in two numbers, x and y, and returns their sum
    >>> add(3, 5)
    8
    >>> add(10, -5)
    5
    """
    return x + y

def subtract(x, y):
    """subtract is a function that takes in two numbers, x and y, and returns their difference
    >>> subtract(10, 49)
    -39
    >>> subtract(11, -12)
    23
    """
    pass

def divide(x, y):
    """divide is a function that takes in two numbers, x and y, and returns x divided by y
    >>> divide(10, 5)
    2.0
    >>> divide(11, -2)
    -5.5
    """
    pass

def divide_whole(x, y):
    """divide_whole functions the same as divide, except it will not return a remainder
    >>> divide_whole(11, 2)
    5
    >>> divide_whole(101, 10)
    10
    """
    pass

def power(x, y):
    """power will raise x to the y-th power
    >>> power(2, 3)
    8
    >>> power(25, .5)
    5.0
    """
    pass

def remainder(x, y):
    """remainder will return the remainder produced from dividing x by y
    >>> remainder(11, 5)
    1
    >>> remainder(47, 5)
    2
    """
    pass




if __name__ == "__main__":
    run_tests()
