


""" YOUR TESTS WILL AUTOMATICALLY RUN """
""" GO BACK TO LESSON1.PY """












def run_tests():
    import main
    counter, counter2 = 0, 0

    if main.problem1 == 112896:
        counter += 1
        print("Operation 1 passed! \n")
    else:
        print("Operation 1 failed. \n Expected: __ \n Got: {} \n".format(main.problem1))

    if main.problem2 == 4:
        counter += 1
        print("Operation 2 Passed! \n")
    else:
        print("Operation 2 failed. \n Expected: __ \n Got: {} \n".format(main.problem2))

    if main.problem3 == 20:
        counter += 1
        print("Operation 3 Passed! \n")
    else:
        print("Operation 3 failed. \n Expected: __ \n Got: {} \n".format(main.problem3))

    if main.problem4 == (((10 - 5) ** 2) + ((10 - 5) ** 2)) ** (.5):
        counter += 1
        print("Operation 4 Passed! \n")
    else:
        print("Operation 4 failed. \n Expected: ___ \n Got: {} \n".format(main.problem4))

    if main.problem5 == 26.8701:
        counter += 1
        print("Operation 5 Passed! \n")
    else:
        print("Operation 5 failed. \n Expected: ___ \n Got: {} \n".format(main.problem5))

    if main.problem6 == 15:
        counter += 1
        print("Operation 6 Passed! \n")
    else:
        print("Operation 6 failed. \n Expected: ____ \n Got: {} \n".format(main.problem6))

    if main.problem7 == 17:
        counter += 1
        print("Operation 7 Passed! \n")
    else:
        print("Operation 7 failed. \n Expected: ____ \n Got: {} \n".format(main.problem7))

    if main.x == 3:
        counter2 += 1
        print("Assignment 1 Passed! \n")
    else:
        print("Assignment 1 Failed. \n Expected: ___ \n Got: {} \n".format(main.x))

    if main.y == "Making Waves is Cool":
        counter2 += 1
        print("Assignment 2 Passed! \n")
    else:
        print("Assignment 2 Failed. \n Expected: ___ \n Got: {} \n".format(main.y))

    if main.sum == 17:
        counter2 += 1
        print("Assignment 3 Passed! \n")
    else:
        print("Assignment 3 Failed. \n Expected: 17 \n Got: {} \n".format(main.sum))

    if main.new_sum == 20:
        counter2 += 1
        print("Assignment 4 Passed! \n")
    else:
        print("Assignment 4 Failed. \n Expected: 20 \n Got: {} \n".format(main.new_sum))

    if main.new_new_sum == 20:
        counter2 += 1
        print("Assignment 5 Passed! \n")
    else:
        print("Assignment 5 Failed. \n Expected: 20 \n Got: {} \n".format(main.new_new_sum))


    print("Summary: \n {} Operator Tests Passed \n {} Operator Tests Failed \n \n {} Assignment Tests Passed \n {} Assignment Tests Failed".format(counter, 7 - counter, counter2, 5 - counter2))
