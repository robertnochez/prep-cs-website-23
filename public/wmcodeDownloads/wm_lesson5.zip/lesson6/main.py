from tests import run_tests


real_num = 10
# note that this assignment happens outside of the function
# so that you only have to assign the correct value once

def over_under(guess):
    """over_under is a guessing game that uses user input to generate hints."""
    if guess == real_num:
        print("Yay! You guessed it!")
    elif guess > real_num:
        print("Try something lower than that.")
    elif guess < real_num:
        print("Try something bigger.")


comparator = 10

def compare_numbers(x):
    """This function will determine whether its parameter is less than, greater than,
    or equal to the <comparator> value above, and print a message.

    >>> compare_numbers(10)
    Your number is equal to the comparator.
    >>> compare_numbers(-4)
    Your number is less than the comparator.
    >>> compare_numbers(50893)
    Your number is greater than the comparator.
    """
    ## YOUR CODE HERE ##


def check_grade(passing_grade, actual_grade):
    """check_grade is a function that was written by a worried student. The
    function tells them whether or not they will pass, given the grade they
    need, and the grade they currently have. Assume that both values are arbitrary.

    >>> check_grade(70, 98)
    True
    >>> check_grade(25, 10)
    False
    >>> check_grade(50, -34)
    False
    """
    ## YOUR CODE HERE ##


def weird_operation(x):
    """Someone decided that they didn't like odd or even numbers. They want to
    take any number, x, and:
    - If it's even, divide it by 2, or
    - If it's odd, multiply it by 3 and add 1
    Implement this for them.

    NOTE: How could the modulus operator, %, be useful here?

    >>> weird_operation(9)
    28
    >>> weird_operation(4)
    2
    >>> weird_operation(27)
    82
    """
    ## YOUR CODE HERE ##


    


if __name__ == "__main__":
    run_tests()
