


""" YOUR TESTS WILL AUTOMATICALLY RUN """
""" GO BACK TO LESSON6.PY """




def run_tests():
    from doctest import testmod
    testmod(verbose=True)
