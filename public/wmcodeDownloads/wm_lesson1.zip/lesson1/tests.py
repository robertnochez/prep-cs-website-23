


""" YOUR TESTS WILL AUTOMATICALLY RUN """
""" GO BACK TO LESSON1.PY """






def run_tests():
    import main
    counter = 0

    if main.problem1 == 1:
        counter += 1
        print("Test 1 passed! \n")
    else:
        print("Test 1 failed. \n Expected: __ \n Got: {} \n".format(main.problem1))

    if main.problem2 == 50.0:
        counter += 1
        print("Test 2 Passed! \n")
    else:
        print("Test 2 failed. \n Expected: __ \n Got: {} \n".format(main.problem2))

    if main.problem3 == 3:
        counter += 1
        print("Test 3 Passed! \n")
    else:
        print("Test 3 failed. \n Expected: __ \n Got: {} \n".format(main.problem3))

    if main.problem4 == 704:
        counter += 1
        print("Test 4 Passed! \n")
    else:
        print("Test 4 failed. \n Expected: ___ \n Got: {} \n".format(main.problem4))

    if main.problem5 == 2:
        counter += 1
        print("Test 5 Passed! \n")
    else:
        print("Test 5 failed. \n Expected: _ \n Got: {} \n".format(main.problem5))

    if main.problem6 == 2020:
        counter += 1
        print("Test 6 Passed! \n")
    else:
        print("Test 6 failed. \n Expected: ____ \n Got: {} \n".format(main.problem6))

    print("Summary: \n {} Tests Passed \n {} Tests Failed".format(counter, 6 - counter))
