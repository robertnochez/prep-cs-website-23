from tests import run_tests

def choose_clothes(temperature):
    """Takes in the temperature, in degrees Fahrenheit, and makes a suggestion on what to wear.

    >>> choose_clothes(80)
    'You do not need a sweater. A t-shirt will be fine.'
    >>> choose_clothes(-32)
    'You should wear a jacket to be ready for any weather.'
    """
    response = "This will be changed."
    if temperature >= 75:
        response = "You do not need a sweater. A t-shirt will be fine."
    elif temperature >= 65:
        response = "The weather will not be that bad. Wear a hoodie."
    else:
        response = "You should wear a jacket to be ready for any weather."
    return response


def test_even(x):
    """Given an integer number, x, test_even will determine whether x is:
    1. Evenly divisible by 2
    2. Not evenly divisible by 2

    NOTE: The modulus operator, %, can help figure out even divisors.
    --> if x % y = 0 then x is evenly divisible by y

    >>> test_even(60)
    'Your input is an even number.'
    >>> test_even(15)
    'Your input is not an even number.'
    >>> test_even(36)
    'Your input is an even number.'
    """
    ## YOUR CODE HERE ##


def determine_grade(percentage):
    """A school has the following grading system:
    - 90% or higher = A
    - 80% or higher = B
    - 70% or higher = C
    - 60% or higher = D
    - Anything lower = F
    Write a function determine_grade that returns a user's grade,
    given their integer percentage.

    NOTE: The following comparison operators will be very useful:
    --> Less than or equal to, <=
    --> Greater than or equal to, >=

    >>> determine_grade(75)
    'Your grade is C.'
    >>> determine_grade(-24)
    'Your grade is F.'
    >>> determine_grade(104)
    'Your grade is A.'
    """
    ## YOUR CODE HERE ##


def over_under(x):
    """Given an integer number, x, over_under will return either:
    1. Its square if it's value is less than 25, or
    2. Its square root if it's value is less than 50, or
    5. The sum of its square and square root if it's value is greater than 50

    NOTE: In which order should the conditional statements go?
    NOTE: Would helper functions make sense in this example?

    >>> over_under(4)
    16
    >>> over_under(36)
    6.0
    >>> over_under(60)
    3607.7459666924146
    """
    ## YOUR CODE HERE ##



if __name__ == "__main__":
    run_tests()
