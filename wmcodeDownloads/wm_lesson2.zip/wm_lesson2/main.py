from tests import run_tests

"""
HINTS:

+	adds two operands together
-	subtracts one operand from the other
*	multiplies operands
/	divides one operand in terms of the other
//	floor division - "integer division" that cuts off the decimal point
%   modulo - returns the remainder caused by division
** 	power operator

problem2 -- Floor dividing by 10, x // 10, will cut the last digit off of a number x
            Using modulo 10, x % 10, will give the last digit in a number x
problem3 -- The discriminant of a quadratic in the form Ax^2 + Bx + C is:
                (B squared) - (4 * A * C)
problem4-5 -- Square root is the same thing as something to the (.5) power; x ** (.5)
            Recall that the distance formula is:
                the square root of ((y2 - y1) ** 2) + ((x2 - x1) ** 2)
problem6-7 -- You can find the length of a triangle's hypotenuse, C, using lengths A and B:
                C = square root of (A squared) + (B squared)
            Floor dividing, x // 1, will cut off anything after x's decimal point

----> PARENTHESIS ARE IMPORTANT
"""


"""Write an expression that evaluates the product of 24 and 14
        then squares it
"""
problem1 = 0


"""Write an expression that gives the second to last number in 4799028742"""
problem2 = 0


"""Write an expression that gives the discriminant of the quadratic expression:
        4x^2 - 10x + 5
"""
problem3 = 0


"""Write an expression that calculates the distance between the points: (5, 5) and (10, 10).
        Where (5, 5) is Point 1 and (10, 10) is Point 2
"""
problem4 = 0


"""Write an expression that calculates the distance between the points: (0, 0) and (20, 20).
        Where (0, 0) is Point 1 and (20, 20) is Point 2
"""
problem5 = 0


"""Write an expression to find the length of the hypotenuse, C, of a triangle with lengths
        A = 9 and B = 12
        If your answer is a whole number, don't include the decimal
"""
problem6 = 0


"""Write an expression to find the length of the hypotenuse, C, of a triangle with lengths
        A = 10 and B = 14
        If your answer is a whole number, don't include the decimal
"""
problem7 = 0


"""
ASSIGNMENT PRACTICE:

>>> x = "Hello World"
>>> y = "Making Waves is Cool"
>>> x = 3
"""
x = "your answer here"
y = "your answer here"

"""
* continues from above *
>>> y = 7
>>> sum = x + y + y
"""
sum = "your answer here"

"""
* continues from above *
>>> new_sum = sum + x
>>> new_sum_two = new_sum
"""
new_sum = "your answer here"
new_new_sum = "your answer here"



if __name__ == "__main__":
    run_tests()
