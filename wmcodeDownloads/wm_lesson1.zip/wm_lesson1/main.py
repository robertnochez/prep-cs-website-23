from tests import run_tests

"""Write an expression that gives the value of calling modulus on 10 and 3."""
problem1 = 0


"""Write an expression that evaluates the square root of 196, then adds 36."""
problem2 = (196 ** (.5)) + 36


"""Write an expression that adds the remainders of:
       dividing 12 by 5
       dividing 144 by 13
"""
problem3 = 0


"""Write an expression that multiplies:
       the difference between 86 and 42 with
       the number 4, squared
"""
problem4 = 0


"""Write an expression that divides 3 into 10, with no remainder, then
        return the remainder of dividing 101 by that number.
"""
problem5 = 0


"""Make up your own expression, with any number of calls that evaluates to 2020."""
problem6 = 0



if __name__ == "__main__":
    run_tests()
