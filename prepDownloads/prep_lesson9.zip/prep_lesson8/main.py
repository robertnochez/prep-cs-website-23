from tests import run_tests


fn = lambda x: lambda y: pow(x, y)

def map_recursive(start, end, f):
    """Implement map_to_range from Tuesday's lesson recursively
    
    >>> map_recursive(0, 10, fn(2))
    1
    2
    4
    8
    16
    32
    64
    128
    128
    256
    512
    """
    pass


def fib(i):
    """Return the i-th term of the Fibonacci Sequence.
    
    >>> fib(2)    # --> 0 + 1
    1
    >>> fib(5)    # --> 2 + 3
    5
    >>> fib(10)   # --> 21 + 34
    55
    """
    pass


def factorial_hof(n):
    """Now that we have defined factorial using iteration and recursion,
    implement it using a higher order function. You are not allowed to use
    operators outside of the function calls. 
    --> Think about what we can do to store a counter

    >>> factorial_hof(5)
    120
    >>> factorial(6)
    720
    """
    pass


if __name__ == "__main__":
    run_tests()