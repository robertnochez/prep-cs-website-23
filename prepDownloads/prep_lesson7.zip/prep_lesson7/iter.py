from tests import run_tests

RAs = ['Laila', 'Marcos', 'Destiny', 'Vincent']

def pairRAs(RA_List):
    """ We've lost track of which RAs are supposed to be teaching together! Please list all the
    possible pairs of RAs for each lesson using a loop. Remember there can only be 2 RAs per lesson, 
    they cannot pair with themselves, and the pairs cannot repeat.
 
    >>> pairRAs(RAs)
    Laila and Marcos
    Laila and Destiny
    Laila and Vincent
    Marcos and Destiny
    Marcos and Vincent
    Destiny and Vincent
    
    """
    pass
 
def createRectangle(num, x, y):
    """ Create a picture of a rectangle out of the given number depending
    on the the dimensions given.
 
    >>> createRectangle(3, 6, 5)
    333333
    333333
    333333
    333333
    333333
    >>> createRectangle(1, 4, 2)
    1111
    1111

    """
    pass



if __name__ == "__main__":
    run_tests()


# Created by Destiny Luong 2022