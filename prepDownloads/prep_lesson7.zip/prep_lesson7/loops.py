from tests import run_tests
 
houseLst = {'309 Witches Ave': 'trick', '470 Fairy Way': 'treat', '906 Batman Cave': 'treat'}
shoppingLst1 = ["cabbage", "olive oil", "milk", "tomatoes", "hand soap"]
shoppingLst2 = ["yogurt", "frozen pizza", "spinach", "orange juice", "sour cream"]
 
def groceryList(itemLst):
    """Given the list 'grocery' print each item on the list one by one
    using an iterator!
 
    >>> groceryList(shoppingLst1)
    cabbage
    olive oil
    milk
    tomatoes
    hand soap
    >>> groceryList(shoppingLst2)
    yogurt
    frozen pizza
    spinach
    orange juice
    sour cream
    """
    pass
 
def trickOrTreat(houses):
    """ You are going trick or treating! Create a generator that check whether each
    house has a trick or a treat by yielding "[Insert address here] has given you a trick!"
    or "[Insert address here] has given you a treat!"
 
    >>> TorTgen = trickOrTreat(houseLst)
    >>> next(TorTgen)
    '309 Witches Ave has given you a trick!'
    >>> next(TorTgen)
    '470 Fairy Way has given you a treat!'
    >>> next(TorTgen)
    '906 Batman Cave has given you a treat!'
    """
    pass



if __name__ == "__main__":
    run_tests()


# Created by Destiny Luong 2022